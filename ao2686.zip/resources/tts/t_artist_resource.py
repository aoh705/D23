from resources.mysql_data_service import MySQLDataService, MySQLDataServiceConfig
from resources.imdb_resources.artist_resource import ArtistResource
import json
from service_factory import ServiceFactory

service_factory = ServiceFactory()
artist_resource = service_factory.get_resource("ArtistResource")


def t1():

    a_resource = artist_resource
    result = a_resource.get_by_key("nm0727778")
    print("t1: result = \n", json.dumps(result.dict(), indent=2))


def t2():

    a_resource = artist_resource
    result = a_resource.get(primaryName='Maise Williams')
    for i in range(len(result)):
        print(json.dumps(result[i].dict(), indent=2))

def t3():
    a_resource = artist_resource
    result = a_resource.delete(primaryName='Tom Hanks', birthYear = "1960", deathYear = '1960')
    print("Number of rows affected by the insertion: ", result)

def t4():
    a_resource = artist_resource
    result = a_resource.update(primaryName='Bar Kroitoro', newValues={"nconst":"tt123456", "primaryProfession": 'Project Manager', "KnownForTitel" : 'Goofy;'})
    print("Number of rows affected by the insertion: ", result)


if __name__ == "__main__":
    #t1()
    t2()
    #t3()
